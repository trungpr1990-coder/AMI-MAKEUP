# Hướng dẫn lấy YouTube Data API key (miễn phí)

Skill cần một **API key** để gọi YouTube Data API v3. Key là **miễn phí**, hạn mức mặc định **10.000 đơn vị/ngày** (đủ cho hàng chục lần research mỗi ngày).

## Các bước (5 phút)

1. Vào **Google Cloud Console**: https://console.cloud.google.com/
   (Đăng nhập bằng tài khoản Google bất kỳ.)

2. Tạo một **Project** mới:
   - Bấm menu chọn project (góc trên) → **New Project** → đặt tên (vd `research-youtube`) → **Create**.

3. Bật **YouTube Data API v3**:
   - Vào menu trái → **APIs & Services** → **Library**.
   - Gõ tìm **"YouTube Data API v3"** → mở ra → bấm **Enable**.

4. Tạo **API key**:
   - Vào **APIs & Services** → **Credentials**.
   - Bấm **+ Create Credentials** → **API key**.
   - Copy chuỗi key hiện ra (dạng `AIza...`).

5. (Khuyến nghị) **Giới hạn key** cho an toàn:
   - Bấm vào key vừa tạo → mục **API restrictions** → chọn **Restrict key** → tick **YouTube Data API v3** → **Save**.

## Dán key vào skill

- Mở thư mục skill `hmh-mkt-research-youtube`.
- Đổi tên file `.env.example` thành `.env`.
- Mở `.env`, thay dòng key thành key của bạn:

  ```
  YOUTUBE_API_KEY=AIza...key-cua-ban...
  ```

> Skill cũng tự tìm `.env` ở thư mục gốc dự án (đi ngược lên tối đa 8 cấp), nên bạn có thể đặt `.env` ở thư mục gốc workspace nếu muốn dùng chung cho nhiều skill.

## Hết quota thì sao?

- Mỗi trang search tốn 100 đơn vị; quét 100 video = 200 đơn vị.
- Nếu báo lỗi `quotaExceeded`: đợi sang ngày hôm sau (quota reset theo giờ Thái Bình Dương), hoặc tạo project/key khác, hoặc xin tăng quota trong Cloud Console.

## Lưu ý bảo mật

- **Không chia sẻ key công khai**, không commit `.env` lên GitHub.
- Key này chỉ đọc dữ liệu công khai của YouTube, không truy cập được tài khoản của bạn.
